module Liftoff
  VERSION = '1.6.0.rc33'
end
